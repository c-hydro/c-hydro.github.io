
# CIMA Github Frontpage

Pagina di presentazione del repository Git di CIMA Foundation


## Utilizzo

Per creare nuove pagine

* Copiare e rinominare la pagina "template.html"
* Modificare la variabile main con il contenuto HTML della nuova pagina
* Modificare il campo hidden "title" per adatare il titolo della pagina
* Aggiungere lìemento di menu nel file "navbar.html"

## Github API

Per poter ottenere la lista dei repositori privati dell'organizzazione corrispondente bisogna creare un token sul sito di github ( ma non è possibile usarlo su una pagina hostata da github stesso, per i repo pubblici non serve un token)